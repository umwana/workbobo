/** Automatically generated file. DO NOT MODIFY */
package com.example.bob;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}